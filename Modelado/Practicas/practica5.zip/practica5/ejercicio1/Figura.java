package practica5.ejercicio1;

public interface Figura {
    void dibujar();
    double area();
}
